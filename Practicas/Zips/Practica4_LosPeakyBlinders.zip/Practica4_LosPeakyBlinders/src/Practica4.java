/**
 * Class to the make everything work
 */
public class Practica4 {

    /**
     * Main method
     * 
     * @param args args
     */
    public static void main(String[] args) {

        ShipSeller seller = new ShipSeller();
        seller.work();

    }
}
