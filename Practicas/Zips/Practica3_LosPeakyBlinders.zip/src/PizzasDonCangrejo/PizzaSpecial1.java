package PizzasDonCangrejo;

/**
 * Class to represent a special pizza 1.
 */
public class PizzaSpecial1 extends Pizza {

    /**
     * Constructor for a special pizza 1.
     */
    public PizzaSpecial1() {
        name = "Pizza Especial 1";
        price = 150.00;
        meat = "Pollo";
        dough = "Gruesa";
        cheese = "Manchego";
    }

}