package PizzasDonCangrejo;

/**
 * Class to represent a special pizza 2.
 */
public class PizzaSpecial2 extends Pizza {

    /**
     * Constructor for a special pizza 2.
     */
    public PizzaSpecial2() {
        name = "Pizza Especial 2";
        price = 299.00;
        meat = "Salchicha";
        dough = "Gruesa";
        cheese = "Manchego";
    }

}
