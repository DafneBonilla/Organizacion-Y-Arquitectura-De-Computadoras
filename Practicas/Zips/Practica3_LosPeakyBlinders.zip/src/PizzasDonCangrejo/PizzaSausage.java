package PizzasDonCangrejo;

/**
 * Class to represent a sausage pizza.
 */
public class PizzaSausage extends Pizza {

    /**
     * Constructor for a sausage pizza.
     */
    public PizzaSausage() {
        name = "Pizza de Salchicha";
        price = 130.00;
        meat = "Salchicha";
        dough = "Delgada";
        cheese = "Cheddar";
    }

}
