# **Práctica 2: Introducción a C**

## Bonilla Reyes Dafne - 319089660


## **📌 Nota**

Por el uso de la biblioteca `math.h`, a veces al compilar hay un error, esto porque se debe llamar explícitamente la biblioteca con el comando `-lm` al compilar.