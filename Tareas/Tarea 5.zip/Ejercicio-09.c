#include <stdio.h>
#include <signal.h>
#include <setjmp.h>
#include <limits.h>

jmp_buf exceptionBuffer;

void handleException(int signal) {
    if (signal == SIGFPE) {
        printf("Ocurrió una excepción de división entre cero\n");
    } else if (signal == SIGSEGV) {
        printf("Ocurrió una excepción de desbordamiento aritmético\n");
    }
    longjmp(exceptionBuffer, 1);
}

int main() {
    int t0 = 0;
    int result;

    // Establecer el manejador de señales
    signal(SIGFPE, handleException);
    signal(SIGSEGV, handleException);

    // División entre cero
    if (setjmp(exceptionBuffer) == 0) {
        result = 10 / t0;
        printf("Resultado de la división: %d\n", result);
    }

    // Desbordamiento aritmético
    if (setjmp(exceptionBuffer) == 0) {
        result = INT_MAX + 1;
        printf("Resultado del desbordamiento: %d\n", result);
    }

    return 0;
}